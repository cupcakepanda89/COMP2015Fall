class Message {
    constructor(user, messageContent) {
        this.user = user;
        this.content = messageContent;
    }
}