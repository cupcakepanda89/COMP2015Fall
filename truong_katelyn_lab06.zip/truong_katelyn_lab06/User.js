class User {
    constructor(name) {
        this.username = name;
    }
}