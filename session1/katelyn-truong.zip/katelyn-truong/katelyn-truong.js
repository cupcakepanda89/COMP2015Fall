/**
 * Created by katelyntruong on 2017-11-07.
 */
var w = document.getElementById('cat').clientWidth;
var h = document.getElementById('cat').clientHeight;
document.getElementById('bird').width=w;
document.getElementById('bird').height=h;




